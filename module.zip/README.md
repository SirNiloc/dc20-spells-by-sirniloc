# Spells by SirNiloc (DC20)
Will add additional spells for the DC20 game system, is also a dependancy for my ancestry module. (https://github.com/SirNiloc/ancestries-by-sirniloc-dc20)

This uses token and actor artwork by Caeora.
https://www.caeora.com/content-use